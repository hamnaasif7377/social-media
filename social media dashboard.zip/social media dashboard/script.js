document.addEventListener('DOMContentLoaded', () => {
    // Sample data to be used in the dashboard
    const data = {
        user: {
            name: 'Hamna Asif', /* User's name */
            profilePicture: 'profile.png', /* Path to the user's profile picture */
            followers: 1200, /* Number of followers */
            engagementRate: 4.5, /* Engagement rate of the user */
            activityTimeline: [
                { date: '2023-01-01', activity: 'Posted a photo' }, /* Activity entry */
                { date: '2023-01-02', activity: 'Gained 100 followers' } /* Activity entry */
            ]
        },
        metrics: {
            followerGrowth: [100, 150, 200, 250, 300], /* Data for follower growth chart */
            engagementRates: [4.2, 4.3, 4.4, 4.5, 4.6] /* Data for engagement rate chart */
        }
    };

    updateDashboard(data); /* Call function to update dashboard with data */

    function updateDashboard(data) {
        document.querySelector('.profile-picture').src = data.user.profilePicture; /* Update profile picture */
        document.querySelector('.user-name').textContent = data.user.name; /* Update user name */
        document.getElementById('total-followers').textContent = data.user.followers; /* Update total followers count */

        const activityTimeline = document.getElementById('activityTimeline');
        activityTimeline.innerHTML = ''; /* Clear existing activity timeline entries */
        data.user.activityTimeline.forEach(activity => {
            const li = document.createElement('li');
            li.textContent = `${activity.date}: ${activity.activity}`; /* Add new activity entry */
            activityTimeline.appendChild(li);
        });

        const ctxFollowerGrowth = document.getElementById('followerGrowthChart').getContext('2d');
        new Chart(ctxFollowerGrowth, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'], /* X-axis labels */
                datasets: [{
                    label: 'Follower Growth',
                    data: data.metrics.followerGrowth, /* Data for follower growth chart */
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1,
                    fill: false
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true /* Start y-axis at zero */
                    }
                }
            }
        });

        const ctxEngagementRate = document.getElementById('engagementRateChart').getContext('2d');
        new Chart(ctxEngagementRate, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'], /* X-axis labels */
                datasets: [{
                    label: 'Engagement Rate',
                    data: data.metrics.engagementRates, /* Data for engagement rate chart */
                    backgroundColor: 'rgba(153, 102, 255, 0.2)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true /* Start y-axis at zero */
                    }
                }
            }
        });
    }
});
